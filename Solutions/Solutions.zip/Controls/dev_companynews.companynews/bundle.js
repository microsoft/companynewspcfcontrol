var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./companynews/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./companynews/BingParser.ts":
/*!***********************************!*\
  !*** ./companynews/BingParser.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.BingParser = void 0; // Copyright (c) Microsoft Corporation.\n// Licensed under the MIT License.\n\nvar BingParser =\n/** @class */\nfunction () {\n  function BingParser(json) {\n    this._json = json;\n  }\n\n  BingParser.prototype.getNewsCount = function () {\n    return this._json.value.length;\n  };\n\n  BingParser.prototype.getNewsAtIndex = function (index) {\n    return this._json.value[index];\n  };\n\n  BingParser.prototype.hasImage = function (index) {\n    if (this.getNewsAtIndex(index).image) return true;else return false;\n  };\n\n  BingParser.prototype.getImageWidth = function (index) {\n    return 60;\n  };\n\n  BingParser.prototype.getImageHeight = function (index) {\n    /*let item = this.getNewsAtIndex(index);\r\n    let height = Math.round(60 * item.image.thumbnail.height / item.image.thumbnail.width);*/\n    return 60;\n  };\n\n  BingParser.prototype.getImageUrl = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.image.thumbnail.contentUrl;\n  };\n\n  BingParser.prototype.hasCategory = function (index) {\n    var item = this.getNewsAtIndex(index);\n\n    if (item.category) {\n      return true;\n    } else {\n      return false;\n    }\n  };\n\n  BingParser.prototype.getCategory = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.category;\n  };\n\n  BingParser.prototype.getUrl = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.url;\n  };\n\n  BingParser.prototype.getDatePublished = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.datePublished;\n  };\n\n  BingParser.prototype.getTitle = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.name;\n  };\n\n  return BingParser;\n}();\n\nexports.BingParser = BingParser;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./companynews/BingParser.ts?");

/***/ }),

/***/ "./companynews/Constants.ts":
/*!**********************************!*\
  !*** ./companynews/Constants.ts ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.Constants = void 0; // Copyright (c) Microsoft Corporation.\n// Licensed under the MIT License.\n\nvar Constants =\n/** @class */\nfunction () {\n  function Constants() {\n    this.NewsSource = \"Bing\"; // Bing Or Google Or Any other source if implemented\n    // Settings For News service Provider\n\n    this.MoreNews = \"https://www.bing.com/news/search\";\n    this.Count = 4;\n  }\n\n  return Constants;\n}();\n\nexports.Constants = Constants;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./companynews/Constants.ts?");

/***/ }),

/***/ "./companynews/GoogleParser.ts":
/*!*************************************!*\
  !*** ./companynews/GoogleParser.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.GoogleParser = void 0; // Copyright (c) Microsoft Corporation.\n// Licensed under the MIT License.\n\nvar GoogleParser =\n/** @class */\nfunction () {\n  function GoogleParser(json) {\n    this._json = json;\n  }\n\n  GoogleParser.prototype.getNewsCount = function () {\n    return this._json.articles.length;\n  };\n\n  GoogleParser.prototype.getNewsAtIndex = function (index) {\n    return this._json.articles[index];\n  };\n\n  GoogleParser.prototype.hasImage = function (index) {\n    if (this.getNewsAtIndex(index).image) return true;else return false;\n  };\n\n  GoogleParser.prototype.getImageWidth = function (index) {\n    return 60;\n  };\n\n  GoogleParser.prototype.getImageHeight = function (index) {\n    return 60;\n  };\n\n  GoogleParser.prototype.getImageUrl = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.image;\n  };\n\n  GoogleParser.prototype.hasCategory = function (index) {\n    return false;\n  };\n\n  GoogleParser.prototype.getCategory = function (index) {\n    return \"\";\n  };\n\n  GoogleParser.prototype.getUrl = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.url;\n  };\n\n  GoogleParser.prototype.getDatePublished = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.publishedAt;\n  };\n\n  GoogleParser.prototype.getTitle = function (index) {\n    var item = this.getNewsAtIndex(index);\n    return item.title;\n  };\n\n  return GoogleParser;\n}();\n\nexports.GoogleParser = GoogleParser;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./companynews/GoogleParser.ts?");

/***/ }),

/***/ "./companynews/index.ts":
/*!******************************!*\
  !*** ./companynews/index.ts ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.companynews = void 0;\n\nvar Constants_1 = __webpack_require__(/*! ./Constants */ \"./companynews/Constants.ts\");\n\nvar BingParser_1 = __webpack_require__(/*! ./BingParser */ \"./companynews/BingParser.ts\");\n\nvar GoogleParser_1 = __webpack_require__(/*! ./GoogleParser */ \"./companynews/GoogleParser.ts\"); // Copyright (c) Microsoft Corporation.\n// Licensed under the MIT License.\n\n\nvar companynews =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function companynews() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  companynews.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    var val = \"\";\n    if (context.parameters.SearchString.raw != null) val = context.parameters.SearchString.raw;\n    if (context.parameters.APIKey.raw != null) this._apikey = context.parameters.APIKey.raw;\n    if (context.parameters.BaseURL.raw != null) this._baseurl = context.parameters.BaseURL.raw;\n    this._value = val;\n    this._container.innerHTML = this._value;\n    container.appendChild(this._container);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  companynews.prototype.updateView = function (context) {\n    var val = \"\";\n    if (context.parameters.SearchString.raw != null) val = context.parameters.SearchString.raw;\n    if (context.parameters.APIKey.raw != null) this._apikey = context.parameters.APIKey.raw;\n    if (context.parameters.BaseURL.raw != null) this._baseurl = context.parameters.BaseURL.raw;\n    this._value = val;\n    this._context = context;\n    this._container.innerHTML = this._value;\n    this.getNews(val);\n  };\n\n  companynews.prototype.getNews = function (val) {\n    var _this = this;\n\n    if (val == \"\") return;\n    var constants = new Constants_1.Constants();\n    var requestHeaders = new Headers();\n    var uriBase = \"\";\n    var uriQuery = \"\";\n    var morenews = \"\";\n    uriBase = this._baseurl;\n    morenews = constants.MoreNews + \"?q=\" + val;\n\n    if (constants.NewsSource == \"Bing\") {\n      requestHeaders.set(\"Ocp-Apim-Subscription-Key\", this._apikey);\n      uriQuery = uriBase + \"?count=\" + constants.Count + \"&q=\" + val;\n    } else if (constants.NewsSource == \"Google\") {\n      uriQuery = uriBase + \"?count=\" + constants.Count + \"&q=\" + val + \"&token=\" + this._apikey;\n    }\n\n    return fetch(uriQuery, {\n      method: 'GET',\n      headers: requestHeaders\n    }) // the JSON body is taken from the response\n    .then(function (res) {\n      return res.json();\n    }).then(function (res) {\n      // The response has an `any` type, so we need to cast\n      var news = new BingParser_1.BingParser(res);\n\n      if (constants.NewsSource == \"Google\") {\n        news = new GoogleParser_1.GoogleParser(res);\n      }\n\n      var index = 0;\n      var finalhtml = \"\";\n\n      if (news.getNewsCount() == 0) {\n        var html = [];\n        html.push(\"No news available\");\n        finalhtml = finalhtml + html.join(\"\");\n      }\n\n      var startDiv = \"<div style='border-style: none;'>\";\n      finalhtml = finalhtml + startDiv;\n\n      for (index = 0; index < news.getNewsCount(); index++) {\n        var item = news.getNewsAtIndex(index);\n        var html = [];\n        var htmlbuilder = \"<br/>\";\n        htmlbuilder = htmlbuilder + \"<div style='padding-left:-50px;padding-top:20px;border-style: none;vertical-align: bottom;'>\";\n        html.push(htmlbuilder);\n\n        if (news.hasImage(index)) {\n          var width = 60;\n          var height = news.getImageHeight(index);\n          var imageHTML = \"<div width='\" + width + \"'style='float:left;border-style: none;'>\";\n          imageHTML = imageHTML + \"<img style='padding-right:10px; display:block; text-align:justify;' src='\" + news.getImageUrl(index) + //\"&h=\" + height + \"&w=\" + width + \n          \"' width=\" + width + \" height=\" + height + \">\";\n          imageHTML = imageHTML + \"</div>\";\n          html.push(imageHTML);\n        }\n\n        var titleHTML = \"<div ><a style='padding-left:10px' href='\" + news.getUrl(index) + \"'>\" + news.getTitle(index) + \"</a></div>\";\n        html.push(titleHTML + \"</div>\");\n        if (news.hasCategory(index)) html.push(\"<div style='style='float:left;padding-left:50px;border-style: none;vertical-align: bottom;font-family: 'Segoe UI Regular', 'Segoe UI';'> - \" + news.getCategory(index));\n        html.push(\" (\" + _this.getHost(news.getUrl(index)) + \")\");\n        var d = new Date(news.getDatePublished(index));\n        /*let mins =  d.getMinutes()+\"\";\r\n        if( d.getMinutes()<10){\r\n            mins = \"0\"+mins;\r\n        }\r\n        let datestring = d.getDate()  + \"-\" + (d.getMonth()+1) + \"-\" + d.getFullYear() + \" \" + d.getHours() + \":\" + mins;*/\n\n        var today = new Date();\n        var diffTime = Math.abs(today.valueOf() - d.valueOf());\n        var diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));\n        var diffHrs = Math.floor(diffTime / (1000 * 60 * 60));\n        var diffMins = Math.floor(diffTime / (1000 * 60));\n        var datestring = \"\";\n\n        if (diffDays != 0) {\n          datestring = diffDays + \"d\";\n        } else if (diffHrs != 0) {\n          datestring = diffHrs + \"h\";\n        } else if (diffMins != 0) {\n          datestring = diffMins + \"m\";\n        }\n\n        var dateHTML = \" - \" + datestring + \"</div>\";\n        html.push(dateHTML);\n        finalhtml = finalhtml + html.join(\"\");\n      }\n\n      if (news.getNewsCount() != 0) {\n        var html = [];\n        var moreNewsHTML = \"<br/><div><a target='_blank' href='\" + morenews + \"'+val>See more on \" + constants.NewsSource + \" News</a></div>\";\n        html.push(moreNewsHTML);\n        finalhtml = finalhtml + html.join(\"\");\n      }\n\n      var endDiv = \"</div>\";\n      finalhtml = finalhtml + endDiv;\n      _this._container.innerHTML = finalhtml;\n    });\n  };\n\n  companynews.prototype.getHost = function (url) {\n    return url.replace(/<\\/?b>/g, \"\").replace(/^https?:\\/\\//, \"\").split(\"/\")[0].replace(/^www\\./, \"\");\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  companynews.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  companynews.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return companynews;\n}();\n\nexports.companynews = companynews;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./companynews/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('companynews.companynews', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.companynews);
} else {
	var companynews = companynews || {};
	companynews.companynews = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.companynews;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}